/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./**/*.html","./app/*.js"],
  theme: {
    extend: {},
  },
  plugins: [],
}