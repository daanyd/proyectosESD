import "/assets/sass/main.scss";
window.addEventListener("load", () => {
  renderTodoItems();
  initModalWindowEvents();
});

const data = [
  {
    title: "Sumergirme en mi propia miseria",
    done: false,
  },
  {
    title: "Contemplar el abismo",
    done: false,
  },
  {
    title: "Solucionar la hambruna mundial",
    done: false,
  },
  {
    title: "Danza y ejercicio",
    done: false,
  },
  {
    title: "Cena conmigo misma",
    done: false,
  }
];

const renderTodoItems = () => {
  const todoItemsBlock = document.querySelector(".todo_list");
  let todoItemsHTML = "";

  for (let i = 0; i < data.length; i++) {
    const dataItem = data[i];

    todoItemsHTML += `
        <article class="todo_list_items ${dataItem.done ? "done" : ""}">
              <h2 class="todo_list_title">${dataItem.title}</h2>
              <div class="ctas">
                <div class="complete_button">
                  <button class="mark_uncompleted">
                    <i class="bi bi-circle"></i>
                  </button>
                  <button class="mark_completed">
                    <i class="bi bi-circle-fill"></i>
                  </button>
                </div>
                <button class="close_button"><i class="bi bi-x"></i></button>
              </div>
            </article>
            `;
  }
  todoItemsBlock.innerHTML = todoItemsHTML;
  initTodosEvent();
  renderMetaData();
};

const initModalWindowEvents = () => {
  const modalWindow = document.querySelector(".modal_window");
  const modalWindowForm = modalWindow.querySelector("form");
  const addNew = document.querySelector(".new_button");
  addNew.addEventListener("click", (ev) => {
    modalWindow.classList.add("opened");
  });
  modalWindowForm.addEventListener("submit", (ev) => {
    ev.preventDefault();
    const input = modalWindowForm.querySelector("input");
    data.push({
      title: input.value,
      done: false,
    });
    modalWindow.classList.remove("opened");
    modalWindowForm.reset();
    renderTodoItems();
  });
  modalWindowForm.addEventListener("reset", (ev) => {
    modalWindow.classList.remove("opened");
  });
};

const initTodosEvent = () => {
  const todoListItems = document.querySelectorAll(".todo_list_items");
  for (let i = 0; i < todoListItems.length; i++) {
    const todoListItem = todoListItems[i];
    const closeButton = todoListItem.querySelector(".close_button");
    const markCompletedButton = todoListItem.querySelector(".mark_completed");
    const markUnCompletedButton =
      todoListItem.querySelector(".mark_uncompleted");

    closeButton.addEventListener("click", (ev) => {
      data.splice(i, 1);
      renderTodoItems();
    });
    markCompletedButton.addEventListener("click", (ev) => {
      data[i].done = false;
      renderTodoItems();
    });
    markUnCompletedButton.addEventListener("click", (ev) => {
      data[i].done = true;
      renderTodoItems();
    });
  }
};

const renderMetaData = () => {
  const amountDone = document.querySelector(".amount_done");
  const amountTotal = document.querySelector(".amount_total");
  const progressBarCompleted =document.querySelector(".progress_bar_completed")

  let counter = 0;
  for (let i = 0; i < data.length; i++) {
    if (data[i].done) counter++;
  }
  amountTotal.innerHTML = data.length;
  amountDone.innerHTML = counter;
  progressBarCompleted.style.width = (counter / data.length)* 100 +"%"
};
